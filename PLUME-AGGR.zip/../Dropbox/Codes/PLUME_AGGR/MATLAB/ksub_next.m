% subroutine ksub_next ( n, k, iarray, more )
% !
% !*******************************************************************************
% !
% !! KSUB_NEXT generates the K subsets of an N set, one at a time.
% !
% !
% !  Reference:
% !
% !    A Nijenhuis and H Wilf,
% !    Combinatorial Algorithms,
% !    Academic Press, 1978, second edition,
% !    ISBN 0-12-519260-6.
% !
% !  Modified:
% !
% !    15 April 1999
% !
% !  Parameters:
% !
% !    Input, integer N, the size of the set from which subsets are drawn.
% !
% !    Input, integer K, the desired size of the subsets.  K must
% !    be between 0 and N.
% !
% !    Output, integer IARRAY(K).  IARRAY(I) is the I-th element of the
% !    subset.  Thus IARRAY(I) will be an integer between 1 and N.
% !    Note that the routine will return the values in IARRAY
% !    in sorted order: 1 <= IARRAY(1) < IARRAY(2) < ... < IARRAY(K) <= N
% !
% !    Input/output, logical MORE.  Set MORE = .FALSE. before first call
% !    for a new sequence of subsets.  It then is set and remains
% !    .TRUE. as long as the subset computed on this call is not the
% !    final one.  When the final subset is computed, MORE is set to
% !    .FALSE. as a signal that the computation is done.


n = 6;
k = 3;
more = false;

iarray = zeros(1,k);
% m = 0;

% m2 = 0;


if ( k < 0 || k > n )
    
    disp('KSUB_NEXT - Fatal error!');
    fprintf('N= %6i \n',n);
    fprintf('K= %6i \n',k);
    fprintf('but 0 <= K <= N is required!\n');
end


if ( ~more )
    
    m2 = 0;
    m = k;
    
else
    
    if ( m2 < n-m )
        
        m = 0;
        
    end
    
    m = m + 1;
    m2 = iarray(k+1-m);
    
    
end

for j = 1:m,
    
    iarray(k+j-m) = m2 + j;
    
end

more = iarray(1) ~= (n-k+1);


