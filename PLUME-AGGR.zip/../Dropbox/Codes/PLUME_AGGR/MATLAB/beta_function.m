function [ f ] = beta_function( x,x_max,C0,p,q )
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here

f = C0 / beta(p,q) * ( x.^(p-1) .* ( x_max - x ).^(q-1) ) / x_max^(p+q-1);

end

