dt = 0.5 * ( mag_u(1:end-1)+mag_u(2:end) ) .* diff(z); 

T(1) = 0.d0;
T(2:length(dt)+1) = cumsum(dt);


n = 6;

Y(1:size(moments,1),1:n) = moments(1:size(moments,1),1,1:n);
Y(1:size(moments,1),n+1:2*n) = moments(:,2,1:n);

test_sort;

n = 6;


T = T(C);
Y = Y(C,:);

clear mu_test
clear sigma_test
mu_test(:,1) = Y(:,2) ./ Y(:,1);
mu_test(:,2) = Y(:,n+2) ./ Y(:,n+1);
sigma_test(:,1) = (Y(:,3).*Y(:,1) - Y(:,2).^2) ./ (Y(:,1).^2);
sigma_test(:,2) = (Y(:,n+3).*Y(:,n+1) - Y(:,n+2).^2) ./ (Y(:,n+1).^2);


partial_mass_fraction(:,1) = Y(:,1) ./ ( Y(:,1) + Y(:,n+1) );
partial_mass_fraction(:,2) = 1.0 - partial_mass_fraction(:,1);


max_mu = max(max(mu_test));
min_mu = min(min(mu_test));

max_sigma = max(max(sigma_test));
min_sigma = min(min(sigma_test));


N = n/2;


for i=1:size(Y,1),
    
    [xi_i(i,:),w_i(i,:)]=WH(Y(i,1:n),N);
    [xi_j(i,:),w_j(i,:)]=WH(Y(i,n+1:2*n),N);
    
end

xi_i_min = min(min(xi_i));
xi_i_max = max(max(xi_i));

w_i_min = min(min(w_i));
w_i_max = max(max(w_i));

xi_j_min = min(min(xi_j));
xi_j_max = max(max(xi_j));

w_j_min = min(min(w_j));
w_j_max = max(max(w_j));

xi_min = min(xi_i_min,xi_j_min);
xi_max = max(xi_i_max,xi_j_max);

w_min = min(w_i_min,w_j_min);
w_max = max(w_i_max,w_j_max);

plot_figure = 1;

if (plot_figure)
    
    fig = figure;
    
    subplot(3,1,1);
    hold all;
    grid on;box on;
    xlim([min(T),max(T)]);
    xlabel('time (s)');ylabel('M^{(0)}');
    
        
    subplot(3,1,2);
    grid on;
    hold all;box on;
    xlim([min(T),max(T)]);
    ylim([min_mu,max_mu]);
    
    plot([T(2),T(1)],[mu_test(2,1),mu_test(1,1)],'b-');
    
    plot([T(2),T(1)],[mu_test(2,1),mu_test(1,1)],'r-');
    
%    plot([T(2),T(1)],[partial_mass_fraction(2,1),partial_mass_fraction(1,1)],'b--');
    
%    plot([T(2),T(1)],[partial_mass_fraction(2,1),partial_mass_fraction(1,1)],'r--');

    
    legend('orig','aggr');
    xlabel('time (s)');ylabel('\mu (\phi)');
    
    subplot(3,1,3);
    grid on;
    hold all;box on;
    xlim([min(T),max(T)]);
    ylim([0,max_sigma]);
    xlabel('time (s)');ylabel('Std. dev.');
    
%     subplot(4,1,4);box on;grid on;
%     xlabel('Abscissas');ylabel('Weights');
    
    pause
    
    F(1) = getframe(fig);
    
    for i=2:size(Y,1),
        
        % plot number of particles - M0
        subplot(3,1,1);
        plot([T(i-1),T(i)],[Y(i-1,1),Y(i,1)],'b');
        plot([T(i-1),T(i)],[Y(i-1,n+1),Y(i,n+1)],'r');

%        plot([(i-1),T(i)],[partial_mass_fraction(i-1,1),partial_mass_fraction(i,1)],'b--');
%        plot([T(i-1),T(i)],[partial_mass_fraction(i-1,2),partial_mass_fraction(i,2)],'r--');
        
        % plot the volume - M3
        subplot(3,1,2);
    plot([T(i-1),T(i)],[mu_test(i-1,1),mu_test(i,1)],'b-');
    
    plot([T(i-1),T(i)],[mu_test(i-1,2),mu_test(i,2)],'r-');
        
        % plot the Sauter mean diameter
        subplot(3,1,3);

        plot([T(i-1),T(i)],[sigma_test(i-1,1),sigma_test(i,1)],'b');
        plot([T(i-1),T(i)],[sigma_test(i-1,2),sigma_test(i,2)],'r');
        
%         subplot(4,1,4);
%         plot(xi_i(i,:),w_i(i,:),'bo',xi_j(i,:),w_j(i,:)/sum(w_j(i,:)),'ro');box on;grid on;
%         xlim([xi_min,xi_max]);
%         ylim([0,1]);
%         xlabel('abscissas (m)');ylabel('weights');
        
        pause(0.1);
        
        F(i) = getframe(fig);
        
    end
    
end

(Y(end,2:end)./Y(end,1:end-1)).^3
