function [ kappa ] = coag_kern( diam_1 , diam_2 )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here


    beta = collision_kernel( diam_1 , diam_2 );
    
    alfa = coalescence_efficiency( diam_1 , diam_2 );
    
    kappa = beta .* alfa;
    
    % kappa = 1.d-10;


end

