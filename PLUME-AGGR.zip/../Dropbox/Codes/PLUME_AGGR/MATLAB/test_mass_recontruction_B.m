clear all;

scrsz = get(0,'ScreenSize');

mu = 2.d0;
sigma = 1.6d0;

gas_mass_fraction = 3.d-2;

n_mom = 15;

[ mom_0,mom ] = normal_mass_moments( mu,sigma,n_mom,gas_mass_fraction);


mom(2:n_mom) = mom(1:n_mom-1);
mom(1) = mom_0(:);

tgsd_min = -12;
tgsd_max = 14;

x_min = 1.d-3 * 2^(-tgsd_max);
x_max = 1.d-3 * 2^(-tgsd_min);


[xi,w,mom_quad] = WH(mom(:),n_mom/2);

n_nodes = length(xi);

dx = diff(xi(:));

dx_l(1) = xi(1) - x_min;
dx_l(2:n_nodes) = 0.5 * dx(1:n_nodes-1);

dx_r(1:n_nodes-1) = 0.5 * dx(1:n_nodes-1);
dx_r(n_nodes) = max(x_max,2*xi(n_nodes)) - xi(n_nodes);

dx = dx_l + dx_r;

w_dens = w ./dx;

plot(xi,w_dens,'o-');box on;
hold all;

