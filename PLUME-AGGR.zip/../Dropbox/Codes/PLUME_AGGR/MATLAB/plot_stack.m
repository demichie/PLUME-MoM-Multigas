NumGroupsPerAxis = 4; 
NumStacksPerGroup = 3; 
NumStackElements = 3;

% labels to use on tick marks for groups 
groupLabels = { 'Top \mu'; 'Top \sigma'; 'Column height'; 'Solid Mass Flux Lost' }; 
stackData = rand(NumGroupsPerAxis,NumStacksPerGroup,NumStackElements);

stackData(1,1,1) = 9.2572386576e-01;
stackData(1,1,2) = 6.8627842180e-02;
stackData(1,1,3) = 5.6482920571e-03;

stackData(2,1,1) = 2.8395490940e-04
stackData(2,1,2) = 9.9818826178e-01
stackData(2,1,3) = 1.5277833143e-03

stackData(3,1,1) = 1.8328080481e-01
stackData(3,1,2) = 5.3014762323e-01
stackData(3,1,3) = 2.8657157196e-01

stackData(4,1,1) = 9.7746963701e-01
stackData(4,1,2) = 4.1314339375e-03
stackData(4,1,3) = 1.8398929050e-02

%%

stackData(1,2,1) = 9.9689486050e-01
stackData(1,2,2) = 2.7832124545e-03
stackData(1,2,3) = 3.2192704960e-04

stackData(2,2,1) = 1.0823268481e-04
stackData(2,2,2) = 9.9971751039e-01
stackData(2,2,3) = 1.7425692881e-04

stackData(3,2,1) = 9.6660347362e-01
stackData(3,2,2) = 2.4558449120e-03
stackData(3,2,3) = 3.0940681464e-02

stackData(4,2,1) = 9.5386263416e-01
stackData(4,2,2) = 3.3271234528e-02
stackData(4,2,3) = 1.2866131309e-02

% %%

stackData(1,3,1) = 9.7172027868e-01
stackData(1,3,2) = 2.5878387700e-02
stackData(1,3,3) = 2.4013336244e-03

stackData(2,3,1) = 3.7227494471e-04
stackData(2,3,2) = 9.9877492984e-01
stackData(2,3,3) = 8.5279521094e-04

stackData(3,3,1) = 9.5703862380e-01
stackData(3,3,2) = 2.2604196986e-03
stackData(3,3,3) = 4.0700956506e-02

stackData(4,3,1) = 9.7142815477e-01
stackData(4,3,2) = 1.3968835980e-02
stackData(4,3,3) = 1.4603009247e-02


plotBarStackGroups(stackData, groupLabels); 
set(gca,'FontSize',18) 
set(gcf,'Position',[100 100 720 650]) 
grid on 
set(gca,'Layer','top') % put grid lines on top of stacks