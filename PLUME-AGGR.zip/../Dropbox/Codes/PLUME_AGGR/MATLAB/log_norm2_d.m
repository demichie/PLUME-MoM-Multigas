function [ f ] = log_norm2_d( x , mu, sigma )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

bar_sigma = sigma * log(2);
bar_mu = - mu * log(2);
bar_x = 1000*x;

f1 = 6.d0 * 10^12 ./ ( pi * bar_x.^3 );

f2 = lognpdf(bar_x,bar_mu,bar_sigma);

f = f1 .* f2;

%f = 6.d0 ./ ( sigma * log(2) * pi * sqrt( 2.D0 * pi ) * x.^4 ) .* exp( - ( - log2( 1000 * x) ...
%    - mu ).^2 / ( 2 * sigma^2 ) );

end

