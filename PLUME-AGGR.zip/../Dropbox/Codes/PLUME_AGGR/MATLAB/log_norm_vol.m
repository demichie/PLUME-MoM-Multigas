function [ f ] = log_norm_vol( x , mu, sigma )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

f = 1.d0 ./ ( sigma * sqrt( 2.D0 * pi ) * x ) .* exp( - ( log( x) ...
    - mu ).^2 / ( 2 * sigma^2 ) );

end
