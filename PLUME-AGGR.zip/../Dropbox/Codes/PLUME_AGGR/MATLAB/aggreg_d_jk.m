function dy = aggreg_d_jk(t,y)

n = size(y,1)/2;
dy = zeros(2*n,1);    % a column vector

N = n / 2;

%[y,iter]=CORR(y,n);


[d_i,wi_i,~]=WH(y(1:n),N);
[d_j,wi_j,~]=WH(y(n+1:2*n),N);

for i=1:n,
    
    birth_mom_i = 0.D0;
    death_mom_i = 0.D0;

    birth_mom_j = 0.D0;
    death_mom_j = 0.D0;
        
    for j1=1:N,
                
        for j2=1:N,
           
            diam_i_j1 = d_i(j1);
            diam_i_j2 = d_i(j2);
            diam_j_j1 = d_j(j1);
            diam_j_j2 = d_j(j2);


            % death of org due to org-org aggregation (OK)
            death_mom_i = death_mom_i + wi_i(j1) * wi_i(j2) * diam_i_j1^(i-1) ...
                * coag_kern(diam_i_j1,diam_i_j2);
                                            
            % death of org due to org-nonOrg aggregation (OK)
            death_mom_i = death_mom_i + wi_i(j1) * wi_j(j2) * diam_i_j1^(i-1) ...
                * coag_kern(diam_i_j1,diam_j_j2);
                                            
            % death of nonOrg due to nonOrg-org aggregation (OK)
            death_mom_j = death_mom_j + wi_j(j1) * wi_i(j2) * diam_j_j1^(i-1) ...
                * coag_kern(diam_j_j1,diam_i_j2);
                      
            % death of nonOrg due to nonOrg-nonOrg aggregation
            death_mom_j = death_mom_j + wi_j(j1) * wi_j(j2) * diam_j_j1^(i-1) ...
                * coag_kern(diam_j_j1,diam_j_j2);
                      
            % birth of nonOrg due to org-org aggregation (OK)
            birth_mom_j = birth_mom_j + 0.5D0 * wi_i(j1) * wi_i(j2) ...
                * coag_kern(diam_i_j1,diam_i_j2) * ...
                ( diam_i_j1^3 + diam_i_j2^3 )^((i-1)/3);

                      
            % birth of nonOrg due to nonOrg-nonOrg aggregation
            birth_mom_j = birth_mom_j + 0.5D0 * wi_j(j1) * wi_j(j2) ...
                * coag_kern(diam_j_j1,diam_j_j2) * ...
                ( diam_j_j1^3 + diam_j_j2^3 )^((i-1)/3);

            % birth of nonOrg due to org-nonOrg aggregation (OK)
            birth_mom_j = birth_mom_j + wi_i(j1) * wi_j(j2) ...
                * coag_kern(diam_i_j1,diam_j_j2) * ...
                ( diam_i_j1^3 + diam_j_j2^3 )^((i-1)/3);
            
        end
                
    end
     
    
    if ( i == 4 )
        
        i
        death_mom_i
        death_mom_j
        birth_mom_j
        
    end
    
    dy(i) = real( birth_mom_i - death_mom_i );
        
    dy(n+i) = real( birth_mom_j - death_mom_j );
    
end

disp([dy(4),dy(n+4)]);
disp(t);
pause
% dy
