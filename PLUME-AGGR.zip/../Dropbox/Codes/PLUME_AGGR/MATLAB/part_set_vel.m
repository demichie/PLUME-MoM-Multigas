function Vs = part_set_vel(diam)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

rhop = part_dens(diam);

rho_atm0 = 1.29;
rho_atm = 1.29;

if ( diam <= 1.D-4 )
    
    k1 = 1.19D5;   % (m^2 kg^-1 s^-1 )
    
    Vs = k1 * rhop * sqrt( rho_atm0 / rho_atm ) * ( 0.5D0 * diam ).^2;
    
elseif ( diam <= 1.D-3 )
    
    k2 = 8.D0;    % (m^3 kg^-1 s^-1 )
    
    Vs = k2 * rhop * sqrt( rho_atm0 / rho_atm ) * 0.5D0 * diam;
    
else
    
    k3 = 4.833D0; % (m^2 kg^-0.5 s^-1 )
    CD = 0.75D0;
    
    Vs = k3 * sqrt( rhop / CD ) * sqrt( rho_atm0 / rho_atm ) ...
        * sqrt( 0.5D0 * diam );
    
end

end

