function [ mom_0,mom ] = normal_mass_moments( mu0,sigma0,n_mom,gas_mass_fraction)


phi_min = mu0-5*sigma0;
phi_max = mu0+5*sigma0;


nx = 20000;
phi = linspace(phi_min,phi_max,nx);

f = normpdf(phi,mu0,sigma0)*(1.d0-gas_mass_fraction);

plot(phi,f);

hold all;

[mom_0,~] = momnormal_moment(0,mu0,sigma0);
mom_0 = mom_0*(1.d0-gas_mass_fraction);

mom = zeros(1,n_mom);

for i=1:n_mom,
    
   [mom(i),~] = momnormal_moment(i,mu0,sigma0);    
   mom(i) = mom(i)*(1.d0-gas_mass_fraction);
       
end


disp(mom_0)
disp(mom(1))
disp(mom(2))
disp(mom(3))
disp(mom(4))

mom_check0 = sum(diff(phi).* ( 0.5d0 * ...
        ( f(1:length(phi)-1) + f(2:length(phi)) ) ) );

for k=1:n_mom,

    mom_check(k) = sum(diff(phi).* ( 0.5d0 * ...
        ( f(1:length(phi)-1) .* phi(1:length(phi)-1).^k ...
        + f(2:length(phi)) .* phi(2:length(phi)).^k ) ) );
 
end

disp(mom_check0)
disp(mom_check(1))
disp(mom_check(2))
disp(mom_check(3))
disp(mom_check(4))

end

function [mom,mom_s] = momnormal_moment(i,mu0,sigma0)

syms mu_s sigma_s t

mgf = exp(mu_s*t + t^2*sigma_s^2/2);


mom_s = diff(mgf, t, i);

mom = subs(mom_s,[mu_s,sigma_s,t],[mu0,sigma0,0]);

mom_bis = 0;

for k=0:floor(i/2),
    k
    nchoosek(i,2*k)
    prod(2*k-1:-2:1)
    mom_bis = mom_bis + nchoosek(i,2*k)*prod(2*k-1:-2:1)*sigma0^(2*k)*mu0^(i-2*k);
    pause
end

end