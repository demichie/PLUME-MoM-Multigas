function [ f ] = log_norm_d( x , mu, sigma )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

f = 6.d0 ./ ( sigma * sqrt( 2.D0 * pi^3 ) * x.^4 ) .* exp( - ( log( x) ...
    - mu ).^2 / ( 2 * sigma^2 ) );

end

