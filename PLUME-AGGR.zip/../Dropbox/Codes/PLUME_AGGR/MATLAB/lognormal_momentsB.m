function [ mom_0,mom ] = lognormal_momentsB( mu,sigma,gas_volume_fraction,...
    solid_mass_fractions,d1,d2,rho1,rho2)


tgsd_min = -12;
tgsd_max = 14;

d_min = 1.d-3 * 2^(-tgsd_max);
d_max = 1.d-3 * 2^(-tgsd_min);

nx = 10000;
d = logspace(log10(d_min),log10(d_max),nx);

f = zeros(length(mu),length(d));
rho = zeros(length(mu),length(d));
vel = zeros(length(mu),length(d));
f_vol = zeros(length(mu),length(d));
x = zeros(length(mu),length(d));
ind = zeros(1,length(mu));
C0 = zeros(1,length(mu));


for i=1:length(mu),
    
    C0(i) = 1.d0;
    
    f(i,1:length(d)) = log_norm2_d( d , C0(i) , mu(i), sigma(i) );

    rho(i,1:length(d)) = rho_function( d, d1(i), d2(i), rho1(i), rho2(i) );
  
    vel(i,1:length(d)) = settling_velocity( d, d1(i), d2(i), rho1(i), ...
        rho2(i) );
    
    f_vol(i,1:length(d)) = f(i,1:length(d)) .* ( pi/6 * d.^3 );

    x(i,1:length(d)) = f_vol(i,1:length(d)) .* rho(i,1:length(d));
    
end

vol = zeros(length(mu),1);
mass = zeros(length(mu),1);

for i=2:length(d),
       
    vol = vol + f_vol(1:length(mu),i) * ( d(i) - d(i-1) );
    mass = mass + x(1:length(mu),i) * ( d(i) - d(i-1) );
    
end

tot_mass = sum(mass);

mass_fract = mass / tot_mass;

coeff = solid_mass_fractions' ./ mass_fract;

mom_3(1:length(mu)) = coeff;

tot_vol = pi / 6.D0 * sum( mom_3 );

coeff = coeff / tot_vol * ( 1.D0 - gas_volume_fraction );

for i=1:length(mu),

    C0(i) = coeff(i);
    f(i,:) = f(i,:) * coeff(i);
    f_vol(i,:) = f_vol(i,:) * coeff(i);
    x(i,:) = x(i,:) * coeff(i);
    vol(i) = vol(i) * coeff(i);
    mass(i) = mass(i) * coeff(i);
    
end

x_tot = sum(x);

scrsz = get(0,'ScreenSize');

% figure('Position',[1 scrsz(4)/2 2*scrsz(3)/3 2*scrsz(4)/3])
% 
% for i=1:length(mu),
% 
%     subplot(1,length(mu),i);
%         
%     semilogx(d,vel(i,1:length(d)));
%     
%     xlabel('Diameter (m)');
%     ylabel({'Settling';'Velocity (m/s)'});
%     xlim([d_min d_max]);
%     box on;
%         
% end

%%

figure('Position',[1 scrsz(4)/2 2*scrsz(3)/3 2*scrsz(4)/3])

%%


hold all;

for i=1:length(mu),

    subplot(5,length(mu),i);
        
    loglog(d,f(i,1:length(d)));
    
    xlabel('Diameter (m)');
    ylabel({'Particles number';'distribution'});
    xlim([d_min d_max]);
    box on;
    
    
end

%%

subplot(5,1,2)


for i=1:length(mu),

    semilogx(d,f_vol(i,1:length(d)));
    hold all;
    xlabel('Diameter (m)');
    ylabel({'Particles volume';'distribution'});
    xlim([d_min d_max]);
    box on;

end


%%

subplot(5,1,3);

for i=1:length(mu),
    
    semilogx(d,x(i,1:length(d)));
    hold all;
    xlabel('Diameter (m)');
    ylabel({'Particles mass';'distribution'});
    xlim([d_min d_max]);
    box on;

end

semilogx(d,x_tot,'--');



%%

i0 = ceil(-log2(1000*d_min));
i1 = min(floor(-log2(1000*d)));

n_bins = 500;
bin = linspace(i1,i0,n_bins+1);

d_bins = 2.d0.^( -bin)/1000;

bar_mass = zeros(length(mu),n_bins); 

for i=2:length(d),
  
    if ( d(i) > d_min )
                    
        i_bin = find(d(i)>d_bins,1,'first')-1;
                
        bar_mass(:,i_bin) = bar_mass(:,i_bin) + x(:,i) * ( d(i) - d(i-1) );

    end
        
end

mass_fractions = sum(bar_mass,2)/sum(sum(bar_mass));

subplot(5,1,5);

bin_half = 0.5d0 * ( bin(1:n_bins) + bin(2:n_bins+1) );

bar(bin_half,100*bar_mass'/sum(sum(bar_mass)),'stacked');
xlim([-log2(1000.0*d_max) -log2(1000.d0*d_min)]);
xlabel('Diameter (\phi)');
ylabel({'Total grain size';'distribution';'(mass %)'});

%%


for i=1:length(mu),

    subplot(5,length(mu),3*length(mu)+i);

    bar(bin_half,bar_mass(i,:)'/sum(sum(bar_mass)),'stacked');

    xlim([-log2(1000.0*d_max) -log2(1000.d0*d_min)]);

    xlabel('Diameter (\phi)');
    ylabel({'Grain size';'distribution';'(mass %)'});

end
    

%%
n_mom = 30;

mom = zeros(n_mom,length(mu));

mom_0(1:length(mu)) = C0 .* 6.d0 / pi * 10^(-3*(-3)) .* exp( (-3) ...
       * (-mu*log(2)) + 0.5 * ( -3 )^2 * ( sigma*log(2) ).^2 );

for k=1:n_mom,
          
   mom(k,1:length(mu)) = C0 .* 6.d0 / pi * 10^(-3*(k-3)) .* exp( (k-3) ...
       * (-mu*log(2)) + 0.5 * ( k-3 )^2 * ( sigma*log(2) ).^2 );
   
end

% disp(mom_0)
% disp(mom(1))
% disp(mom(2))
% disp(mom(3))
% disp(mom(4))

mom_check0(1:length(mu)) = sum(diff(d).* ( 0.5d0 * ...
        ( f(1:length(d)-1) + f(2:length(d)) ) ) );

for k=1:n_mom,

    mom_check(k,1:length(mu)) = sum(diff(d).* ( 0.5d0 * ...
        ( f(1:length(d)-1) .* d(1:length(d)-1).^k ...
        + f(2:length(d)) .* d(2:length(d)).^k ) ) );
 
end

% disp(mom_check0)
% disp(mom_check(1))
% disp(mom_check(2))
% disp(mom_check(3))
% disp(mom_check(4))

% phi = -log2(10^3 * d );
% 
% f_phi = f .* 10^(-3) .* 2.^(-phi) * (-log(2));
% 
% mom_phi0(1:length(mu)) = sum(diff(phi).* ( 0.5d0 * ...
%         ( f_phi(1:length(d)-1) + f_phi(2:length(d)) ) ) );
% 
% for k=1:n_mom,
% 
%     mom_phi(k,1:length(mu)) = sum(diff(phi).* ( 0.5d0 * ...
%         ( f_phi(1:length(phi)-1) .* phi(1:length(phi)-1).^k ...
%         + f_phi(2:length(phi)) .* phi(2:length(phi)).^k ) ) );
%  
% end
% 
% % disp(mom_phi0)
% % disp(mom_phi(1))
% % disp(mom_phi(2))
% % disp(mom_phi(3))
% % disp(mom_phi(4))
% 
% %%
% 
% mom_vol0(1:length(mu)) = sum(diff(d).* ( 0.5d0 * ...
%         ( f_vol(1:length(d)-1) + f_vol(2:length(d)) ) ) );
% 
% for k=1:n_mom,
% 
%     mom_vol(k,1:length(mu)) = sum(diff(d).* ( 0.5d0 * ...
%         ( f_vol(1:length(phi)-1) .* d(1:length(phi)-1).^k ...
%         + f_vol(2:length(phi)) .* d(2:length(phi)).^k ) ) );
%  
% end
% 
% disp(mom_vol0)
% disp(mom_vol(1))
% disp(mom_vol(2))
% disp(mom_vol(3))
% disp(mom_vol(4))
% 
% mean_vol = mom_vol(1) / mom_vol0;
% sigma_vol = sqrt(mom_vol(2) / mom_vol0 - ( mom_vol(1) / mom_vol0 )^2);
% 
% fprintf('Mean of particles size distribution in m %i\n', mean_vol);
% fprintf('Sigma of particles size distribution in m %i\n', sigma_vol);
% 
% %% 
% 
% f_vol_phi = f_vol .* 10^(-3) .* 2.^(-phi) * (-log(2));
% 
% mom_vol_phi0(1:length(mu)) = sum(diff(phi).* ( 0.5d0 * ...
%         ( f_vol_phi(1:length(d)-1) + f_vol_phi(2:length(d)) ) ) );
% 
%   
% mom_temp0 = sum(diff(d).* ( 0.5d0 * ...
%         ( f_vol(1:length(d)-1) + f_vol(2:length(d)) ) ) );
%     
%     
% for k=1:n_mom,
% 
%     mom_vol_phi(k,1:length(mu)) = sum(diff(phi).* ( 0.5d0 * ...
%         ( f_vol_phi(1:length(phi)-1) .* phi(1:length(phi)-1).^k ...
%         + f_vol_phi(2:length(phi)) .* phi(2:length(phi)).^k ) ) );
%  
%     mom_temp(k,1:length(mu)) = sum(diff(d).* ( 0.5d0 * ...
%         ( f_vol(1:length(d)-1) .* phi(1:length(d)-1).^k ...
%         + f_vol(2:length(d)) .* phi(2:length(d)).^k ) ) );
%     
% end
% 
% disp(mom_vol_phi0)
% disp(mom_vol_phi(1))
% disp(mom_vol_phi(2))
% disp(mom_vol_phi(3))
% disp(mom_vol_phi(4))
% 
% 
% disp(mom_temp0)
% disp(mom_temp(1))
% disp(mom_temp(2))
% disp(mom_temp(3))
% disp(mom_temp(4))
% 
% 
% mean_vol_phi = mom_vol_phi(1) / mom_vol_phi0;
% sigma_vol_phi = sqrt(mom_vol_phi(2) / mom_vol_phi0 - ( mom_vol_phi(1) / ...
%     mom_vol_phi0 )^2);
% 
% 
% fprintf('Mean of particles size distribution in phi %i\n', mean_vol_phi);
% fprintf('Sigma of particles size distribution in phi %i\n', sigma_vol_phi);
% 

% figure
% plot(phi,-f_vol_phi/mom_vol_phi0);

tot_solid_volume_fraction = pi / 6.D0 * sum( mom(3,:) );

fprintf('Number of particles per unit volume %i\n', mom_0(1:length(mu)));
fprintf('Gas volume fraction %i\n', 1.D0 - tot_solid_volume_fraction);
fprintf('Particles mass fractions %i\n', mass_fractions(1:length(mu)));
fprintf('Number Averaged diameter of particles %d\n', mom(1,1:length(mu))./mom_0(1:length(mu)));
fprintf('Sauter mean diameter of particles %d\n', mom(3,1:length(mu))./mom(2,1:length(mu)));
fprintf('Volume averaged diameter of particles %d\n', mom(4,1:length(mu))./mom(3,1:length(mu)));
fprintf('Average volume of particles %d\n',mom(3,1:length(mu))./mom_0(1:length(mu)));

end


function [ f ] = log_norm2_d( x , C0 , mu, sigma )

bar_sigma = sigma * log(2);
bar_mu = - mu * log(2);
bar_x = 1000*x;

f1 = 6.d0 * 10^12 ./ ( pi * bar_x.^3 );

f2 = lognpdf(bar_x,bar_mu,bar_sigma);

f = C0 * f1 .* f2;

end



function [ rho ] = rho_function( d , d1 , d2 , rho1 , rho2 )

rho = d;

for i = 1:length(d)

    if ( d(i) <= d1 )
        
        rho(i) = rho1;
        
    elseif ( d(i) <= d2 )
        
        rho(i) = rho1 + ( d(i) - d1 ) / ( d2 - d1 ) * ( rho2 - rho1 );
        
    else
        
        rho(i) = rho2;
        
    end
    
end

end

function [ vel ] = settling_velocity( d , d1 , d2 , rho1 , rho2 )

vel = d;
% Textor et al. 2006

for i = 1:length(d)

    rhop = rho_function( d(i) , d1 , d2 , rho1 , rho2 );

    if ( d(i) <= 1.d-4 )
        
        k1 = 1.19D5;
        
        vel(i) = k1 * rhop .* ( 0.5D0 * d(i) ).^2;
        
    elseif ( d(i) <= 1.d-3 )
        
        k2 = 8.D0;
        
        vel(i) = k2 * rhop .* ( 0.5D0 * d(i) );
        
    else
        
        k3 = 4.833D0;
        CD = 0.75D0;
        
        vel(i) = k3 * sqrt( rhop / CD ) .* sqrt( 0.5D0 * d(i) );
        
    end
    
end
end