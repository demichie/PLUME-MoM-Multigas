z = linspace(0.1,40,100);

figure;

for phi=-4:5,
    
    diam = 1.D-3 * 2^(-phi);
    
    for i=1:100,
        
        [Us(i),rho_atm(i)] = settling(diam,z(i));
        
    end
    
    subplot(1,2,1)
    hold all;
    semilogx(Us,z)
    box on;
    
    subplot(1,2,2)
    hold all;
    plot(rho_atm,z)
    box on;
    
end