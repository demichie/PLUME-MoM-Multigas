clear all

mu = 1.0;
sigma = 1.6;

n_mom = 8;

for n = 0:n_mom-1,

    mom0(n+1) = 0.d0;

    for j=0:floor(0.5D0 * n),

        fact2 = factd(2*j-1);

        mom0(n+1) = mom0(n+1) + nchoosek(n,2*j) * fact2 ...
            * sigma^(2*j) * mu^(n-2*j);
    end
    
end


m0(1) = 1;
m0(2) = mu;
m0(3) = mu^2 + sigma^2;
m0(4) = mu^3 + 3 * mu * sigma^2;
m0(5) = mu^4 + 6 * mu^2 * sigma^2 + 3 * sigma^4;
m0(6) = mu^5 + 10 * mu^3 * sigma^2 + 15 * mu * sigma^4;
m0(7) = mu^6 + 15 * mu^4 * sigma^2 + 45 * mu^2 * sigma^4 + 15 * sigma^6;
m0(8) = mu^7 + 21 * mu^5 * sigma^2 + 105 * mu^3 * sigma^4 + 105 * mu * sigma^6;


[xi_PD,w_PD,mom_quad]=PD(mom0,n_mom/2);

plot(xi_PD,w_PD,'o-');

hold all;

[xi_WH,w_WH,mom_quad]=WH(mom0,n_mom/2);

plot(xi_WH,w_WH);


delta_03 = zeros(4,4);

delta_03(1,:) = mom0(1:4);
delta_03(2,:) = mom0(2:5);
delta_03(3,:) = mom0(3:6);
delta_03(4,:) = mom0(4:7);

delta_13 = zeros(4,4);

delta_13(1,:) = mom0(2:5);
delta_13(2,:) = mom0(3:6);
delta_13(3,:) = mom0(4:7);
delta_13(4,:) = mom0(5:8);