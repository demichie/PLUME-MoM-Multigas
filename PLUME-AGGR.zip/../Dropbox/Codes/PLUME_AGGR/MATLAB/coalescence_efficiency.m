function  alfa = coalescence_efficiency( diam_1 , diam_2 )
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here


temp_part = 1000.d0;

if ( temp_part <= 273.D0 )
    
    alfa = 0.09d0;
    
else
        
    rho_1 = part_dens(diam_1);
    rho_2 = part_dens(diam_2);
    
    mu_liq = 5.43D-4;
    
    Stokes = 8.d0 * 0.5D0 * ( rho_1 + rho_2 ) / ( 9.d0 * mu_liq ) ...
    .* diam_1 .* diam_2 ./ ( diam_1 + diam_2 );
    
    Stokes_cr = 1.3D0;
    
    q = 0.8D0;
    
    alfa = 1.D0 ./ ( 1.D0 + ( Stokes / Stokes_cr ) ) .^ q;
    
end

end

