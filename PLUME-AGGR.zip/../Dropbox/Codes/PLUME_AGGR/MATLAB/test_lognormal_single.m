mu = [2];
sigma=[1.6];
gas_volume_fraction = 0.997;
solid_mass_fractions = [1.0];

% the density is assumed to vary linearly between d1 and d2 and to be equal
% to rho1 for d<d1 and to rho2 for d>d2

d1 = [0.1];
d2 = [1.1];
rho1 = [2000];
rho2 = [2000];

lognormal_moments( mu,sigma,gas_volume_fraction,...
    solid_mass_fractions,d1,d2,rho1,rho2);
