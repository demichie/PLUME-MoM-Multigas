function dy = aggreg_phi_jk(t,y)

x_solid = 0.95;
rho_gas = 1.29;
rho_solid = 2000;

% rho_gas = 1;
% rho_solid = 1;
% pi = 6.d0;


rho_mix = 1.0 / ( x_solid / rho_solid + ( 1.0 - x_solid ) / rho_gas );


n = size(y,1)/2;
dy = zeros(2*n,1);    % a column vector

N = n / 2;

%[y,iter]=CORR(y,n);


[phi_i,wi_i,~]=WH(y(1:n),N);
[phi_j,wi_j,~]=WH(y(n+1:2*n),N);


% y

%[phi,w]=PD(y,N);

for i=1:n,
    
    birth_mom_i = 0.D0;
    death_mom_i = 0.D0;

    birth_mom_j = 0.D0;
    death_mom_j = 0.D0;
        
    for j1=1:N,
                
        for j2=1:N,
           
            diam_i_j1 = 1.D-3 * 2.D0 ^ ( - phi_i(j1) );
            diam_i_j2 = 1.D-3 * 2.D0 ^ ( - phi_i(j2) );
            diam_j_j1 = 1.D-3 * 2.D0 ^ ( - phi_j(j1) );
            diam_j_j2 = 1.D-3 * 2.D0 ^ ( - phi_j(j2) );


            % death of org due to org-org aggregation (OK)
            death_mom_i = death_mom_i + wi_i(j1) * wi_i(j2) * phi_i(j1)^(i-1) ...
                * coag_kern(diam_i_j1,diam_i_j2) * 6.D0  ...
                / ( pi * diam_i_j2^3 * part_dens(diam_i_j2) );
                                            
            % death of org due to org-nonOrg aggregation (OK)
            death_mom_i = death_mom_i + wi_i(j1) * wi_j(j2) * phi_i(j1)^(i-1) ...
                * coag_kern(diam_i_j1,diam_j_j2) * 6.D0 ...
                / ( pi * diam_j_j2^3 * part_dens(diam_j_j2) );
                                            
            % death of nonOrg due to nonOrg-org aggregation (OK)
            death_mom_j = death_mom_j + wi_j(j1) * wi_i(j2) * phi_j(j1)^(i-1) ...
                * coag_kern(diam_j_j1,diam_i_j2) * 6.D0 ...
                / ( pi * diam_i_j2^3 * part_dens(diam_i_j2) );
                      
            % death of nonOrg due to nonOrg-nonOrg aggregation
            death_mom_j = death_mom_j + wi_j(j1) * wi_j(j2) * phi_j(j1)^(i-1) ...
                * coag_kern(diam_j_j1,diam_j_j2) * 6.D0 ...
                / ( pi * diam_j_j2^3 * part_dens(diam_j_j2) );
                      
            % birth of nonOrg due to org-org aggregation (OK)
            birth_mom_j = birth_mom_j + 0.5D0 * wi_i(j1) * wi_i(j2) ...
                * coag_kern(diam_i_j1,diam_i_j2) * 6.D0 / pi ...
                * ( part_dens(diam_i_j1) * diam_i_j1^3 ...
                + part_dens(diam_i_j2) * diam_i_j2^3 ) ...
                / ( part_dens(diam_i_j1) * diam_i_j1^3 ...
                * part_dens(diam_i_j2) * diam_i_j2^3 ) ...
                * ( -log( 2.D0^( -3.D0*phi_i(j1) ) ...
                +  2.D0^( -3.D0*phi_i(j2) ) ) ...
                / ( 3.D0*log(2.D0) ) )^(i-1);

                      
            % birth of nonOrg due to nonOrg-nonOrg aggregation
            birth_mom_j = birth_mom_j + 0.5D0 * wi_j(j1) * wi_j(j2) ...
                * coag_kern(diam_j_j1,diam_j_j2) * 6.D0 / pi ...
                * ( part_dens(diam_j_j1) * diam_j_j1^3 ...
                + part_dens(diam_j_j2) * diam_j_j2^3 ) ...
                / ( part_dens(diam_j_j1) * diam_j_j1^3 ...
                * part_dens(diam_j_j2) * diam_j_j2^3 ) ...
                * ( - log( 2.D0^ ( - 3.D0 * phi_j(j1) ) ...
                +  2.D0^ ( -3.D0*phi_j(j2) ) ) ...
                / ( 3.D0*log(2.D0) ) )^(i-1);

            % birth of nonOrg due to org-nonOrg aggregation (OK)
            birth_mom_j = birth_mom_j + wi_i(j1) * wi_j(j2) ...
                * coag_kern(diam_i_j1,diam_j_j2) * 6.D0 / pi ...
                * ( part_dens(diam_i_j1) * diam_i_j1^3 ...
                + part_dens(diam_j_j2) * diam_j_j2^3 ) ...
                / ( part_dens(diam_i_j1) * diam_i_j1^3 ...
                * part_dens(diam_j_j2) * diam_j_j2^3 ) ...
                * ( - log( 2.D0^ ( - 3.D0 * phi_i(j1) ) ...
                +  2.D0^ ( -3.D0*phi_j(j2) ) ) ...
                / ( 3.D0*log(2.D0) ) )^(i-1);
    
            
        end
                
    end
   
     
%     if ( i == 1 )
%         
%         i
%         death_mom_i
%         death_mom_j
%         birth_mom_j
%         
%     end
    
   
    
    dy(i) = rho_mix * real( birth_mom_i - death_mom_i );
        
    dy(n+i) = rho_mix * real( birth_mom_j - death_mom_j );
    
end

% disp([dy(1),dy(n+1)]);
disp(t);
% pause
% dy
