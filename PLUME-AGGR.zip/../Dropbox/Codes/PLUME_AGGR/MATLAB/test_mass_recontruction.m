clear all;

scrsz = get(0,'ScreenSize');

mu = 0.d0;
sigma = 1.6d0;

gas_mass_fraction = 0.03d0;

solid_mass_fractions = 1.d0;

d1 = 1.d-5;
d2 = 1.d-3;

rho1 = 2000;
rho2 = 2000;

[ mom_0,mom ] = lognormal_mass_moments( mu,sigma,gas_mass_fraction,...
    solid_mass_fractions,d1,d2,rho1,rho2);

n_mom = 30;

mom(2:n_mom,:) = mom(1:n_mom-1,:);
mom(1,:) = mom_0(:);

figure;

tgsd_min = -12;
tgsd_max = 14;

x_min = 1.d-3 * 2^(-tgsd_max);
x_max = 1.d-3 * 2^(-tgsd_min);

for i=1:size(mom,2),
    
    [xi(:,i),w(:,i),mom_quad] = WH(mom(:,i),n_mom/2);
    
    n_nodes = length(xi);
            
    dx = diff(xi(:,i));
    
    dx_l(1) = xi(1,i) - x_min;
    dx_l(2:n_nodes) = 0.5 * dx(1:n_nodes-1);
    
    dx_r(1:n_nodes-1) = 0.5 * dx(1:n_nodes-1);
    dx_r(n_nodes) = max(x_max,2*xi(n_nodes,1)) - xi(n_nodes,1);
    
    dx = dx_l + dx_r;
    
    w_dens(:,i) = w(:,i) ./dx';
    
    xi_phi(:,i) = -log2(1000*xi(:,i));

    subplot(1,2,1);
    plot(xi(:,i),w_dens(:,i),'o-');box on;
    hold all;

    subplot(1,2,2);
    plot(xi_phi(:,i),w_dens(:,i),'o-');box on;
    hold all;
    
%    xlim([log10(x_min) log10(x_max)]);
    
    
end


