tgsd_min = -12;
tgsd_max = 14;

xmin = 1.d-3 * 2^(-tgsd_max)
xmax = 1.d-3 * 2^(-tgsd_min)

mu(1) = 0.d0;
sigma(1) = 1.6;

% mu(2) = 4.d0;
% sigma(2) = 1.6;

nx = 5000;
x = logspace(log10(xmin),log10(xmax),nx);

for i = 1:length(mu),
    
    f(i,:) = log_norm2_d(x,mu(i),sigma(i));
    
    x_norm = -log2(1000*x);
    
    subplot(2,2,1);
    
    loglog(x,f(i,:))
    hold all
    xlabel('Diameter (m)');
    ylabel({'Particles number';'distribution'});
    xlim([xmin xmax]);
    subplot(2,2,3);
    
    f_vol(i,:) = f(i,:) * pi / 6.D0 .* x.^(3);
    
    semilogx(x,f_vol(i,:))
    hold all
    xlabel('Diameter (m)');
    ylabel({'Particles volume';'distribution'});
    xlim([xmin xmax]);
    
    subplot(2,2,2);
    
    x_norm = -log2(1000*x);
    
    f_norm(i,:) = f_vol(i,:) .* x * log(2);

    %    y = normpdf(x_norm,mu(i),sigma(i));    
    %    plot(x_norm,f_norm(i,:),x_norm,y,'y--');

    plot(x_norm,f_norm(i,:));
    hold all
    xlim([tgsd_min tgsd_max]);
        
end

subplot(2,2,4);

plot(x_norm,sum(f_norm(:,:),1));
xlim([tgsd_min tgsd_max]);


pause



%%


%%


dx = x(2:end) - x(1:end-1);

for n = 0:9,
    
    disp(n)
    
    for i=1:length(mu),
        
        f_n = f(i,:) .* x.^(n);
        
        f_n_avg = 0.5 * ( f_n(1:end-1) + f_n(2:end) );
        
        mom_n_f = sum( dx .* f_n_avg );
        
        mom_an_f = 6.d0 / pi * 10^(-3*(n-3)) * exp( (n-3)*(-mu(i)*log(2)) ...
            + 0.5 * ( n-3 )^2 * ( sigma(i)*log(2) )^2 );
        
        mom(i,n+1) = mom_an_f;
        
        disp(mom_an_f / mom_n_f)
        
    end
    
end
 
for i=1:length(mu),
        
    n=4;
    mom_4 = 6.d0 / pi * 10^(-3*(n-3)) * exp( (n-3)*(-mu(i)*log(2)) ...
        + 0.5 * ( n-3 )^2 * ( sigma(i)*log(2) )^2 );
    
    n=3;
    mom_3 = 6.d0 / pi * 10^(-3*(n-3)) * exp( (n-3)*(-mu(i)*log(2)) ...
        + 0.5 * ( n-3 )^2 * ( sigma(i)*log(2) )^2 );

    n=2;
    mom_2 = 6.d0 / pi * 10^(-3*(n-3)) * exp( (n-3)*(-mu(i)*log(2)) ...
        + 0.5 * ( n-3 )^2 * ( sigma(i)*log(2) )^2 );
    
    mom_3
    
%     mom_4/mom_3
%    
%     -log2(1000*mom_3/mom_2)
%     
%     -log2(1000*mom_4/mom_3)
   
end


