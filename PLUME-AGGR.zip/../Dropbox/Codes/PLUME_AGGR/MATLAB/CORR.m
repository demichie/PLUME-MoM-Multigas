function [m,iter]=CORR(m,n)
%
% correct a moment set
%
% INPUT:
%   m = moments 
%   n = number of moments
%
% OUTPUT:
%   m    = corrected moment set
%   iter = number of iteration required
%
% define maximum number of iteration
%
iter_max = 10;
%
% define the unitary correction matrix
%
for i=1:n
    for j=1:n
        bkk(i,j) = 0.0;
    end
end
%
for k=1:n
    for i=1:n
        if (i==k) 
            bkk(i,1) = 1.0;
        else
            bkk(i,1) = 0.0;
        end
    end
%  
    for j=2:4
        for i=1:n-j+1
            bkk(i,j) = bkk(i+1,j-1)-bkk(i,j-1);
        end
    end
    
    for i=1:n
        bk(k,i)=bkk(i,4);
    end
    
end
%
check_corr = 1.0;
iter =0.0;
%
% start the correction loop
%
while (check_corr==1.0 && iter<iter_max)
%    
    check_corr = 0.0;
%
    for i=1:n
        d(i,1) = log(m(i));
    end
    for j=2:n+1
        for i=1:n-j+1
            d(i,j) = d(i+1,j-1)-d(i,j-1);
            if (j==3 && d(i,j)<0) 
                check_corr = 1.0;
            end
        end
    end
%    
    d
    pause

    if (check_corr == 1.0)
%        
        iter   = iter + 1.0;
        k_star = 1.0;
%        
        for k=1:n
            cos_quad_alfa(k) = ((bk(k,:)*d(:,4))/((bk(k,:)*bk(k,:)')^0.5*(d(:,4)'*d(:,4))^0.5))^2.0;
            if (cos_quad_alfa(k) >= cos_quad_alfa(k_star)) 
                k_star=k;
            end
        end
%        
        lnck = -(bk(k_star,:)*d(:,4))/(bk(k_star,:)*bk(k_star,:)');
        m(k_star) = exp(lnck)*m(k_star);
%        
    end
%    
end