function [ mom_0,mom ] = lognormal_moments( mu,sigma,gas_volume_fraction,...
    solid_mass_fractions,d1,d2,rho1,rho2)


% min and max diameter expressed in the phi scale

tgsd_min = -6.5;
tgsd_max = 7.5;

% corresponding diamters in meters

d_min = 1.d-3 * 2^(-tgsd_max);
d_max = 1.d-3 * 2^(-tgsd_min);

% number of points for the plots
nx = 50000;

% create a uniform log-spaced interval of diameters
d = logspace(log10(d_min),log10(d_max),nx);

phi = -log2( 1.d3 * d);

% initialize the arrays
f = zeros(length(mu),length(d));
rho = zeros(length(mu),length(d));
vel = zeros(length(mu),length(d));
f_vol = zeros(length(mu),length(d));
x = zeros(length(mu),length(d));
ind = zeros(1,length(mu));
C0 = zeros(1,length(mu));


for i=1:length(mu),
    
    C0(i) = 1.d0;
    
    % evaluate the number densities of particles in d with the lognormal 
    % distribution (number of particles with diamter d for unit volume)
    f(i,1:length(d)) = log_norm2_d( d , C0(i) , mu(i), sigma(i) );

    % evaluate the corresponding densities 
    rho(i,1:length(d)) = rho_function( d, d1(i), d2(i), rho1(i), rho2(i) );
  
    % evaluate the settling velocities
    vel(i,1:length(d)) = settling_velocity( d, d1(i), d2(i), rho1(i), ...
        rho2(i) );

    % evaluate the volume fractions from the particle numbers
    f_vol(i,1:length(d)) = f(i,1:length(d)) .* ( pi/6 * d.^3 );

    % evaluate the mass fractions from the particles number
    x(i,1:length(d)) = f_vol(i,1:length(d)) .* rho(i,1:length(d));
    
    % evaluate the mass fractions from the normal distribution in phi
    x_phi(i,1:length(d)) = normpdf(phi,mu(i),sigma(i));
    
end


% the fractions must be corrected in order to have the solid volume 
% fractions, function of the input gas_volume_fraction and
% solid_mass_fraction and of the densities. 

% average solid densities for the different "families"
rho_solid_avg = sum(x') ./ sum(f_vol');

% average density of the total solid
rho_solid_tot_avg = 1.D0 / sum( solid_mass_fractions' ./ rho_solid_avg' );

% volume fractions of the particles with respect to the total solid
alfa_s = solid_mass_fractions * rho_solid_tot_avg ./ rho_solid_avg;

% volume fractions of the solids, with respect to the gas-solid mixture
solid_volume_fraction = alfa_s * ( 1.D0 - gas_volume_fraction );

C0 = solid_volume_fraction;

for i=1:length(mu),

    f(i,:) = f(i,:) * C0(i);
    f_vol(i,:) = f_vol(i,:) * C0(i);
    x(i,:) = x(i,:) * C0(i);
    
end

x_tot = sum(x);

scrsz = get(0,'ScreenSize');


%%

%figure('Position',[1 scrsz(4)/2 2*scrsz(3)/3 2*scrsz(4)/3])
figure
%% 
% Plot of the particle number for unit volume as a function of the diameter 
% expressed in meters.

hold all;

for i=1:length(mu),

    subplot(5,length(mu),i);
        
    loglog(d,f(i,1:length(d)));
    
    xlabel('Diameter (m)');
    ylabel({'Particles number';'distribution'});
    xlim([d_min d_max]);
    box on;
    
    
end

set(gca,'XDir','reverse');

%%
% Plot of the volume fraction distribution as a function of the diameter 
% expressed in meters.

subplot(5,1,2)


for i=1:length(mu),

    semilogx(d,f_vol(i,1:length(d)));
    hold all;
    xlabel('Diameter (m)');
    ylabel({'Particles volume';'distribution'});
    xlim([d_min d_max]);
    box on;

end

set(gca,'XDir','reverse');

%%
% Plot of the mass fraction distribution as a function of the diameter 
% expressed in meters.

subplot(5,1,3);

for i=1:length(mu),
    
    semilogx(d,x(i,1:length(d)));
    hold all;
    xlabel('Diameter (m)');
    ylabel({'Particles mass';'distribution'});
    xlim([d_min d_max]);
    box on;

end

set(gca,'XDir','reverse');

%%
% Plot of the normal distribution of the mass fraction in phi

for i=1:length(mu),

    subplot(5,length(mu),3*length(mu)+i);

    plot(phi,x_phi(i,1:length(d)));
        
    xlim([-log2(1000.0*d_max) -log2(1000.d0*d_min)]);

    xlabel('Diameter (\phi)');
    ylabel({'Mass fraction';'distribution'});

end
    

%%

i0 = ceil(-log2(1000*d_min));
i1 = min(floor(-log2(1000*d)));


n_bins = 15;

bin = linspace(i1,i0,n_bins+1);

d_bins = 2.d0.^( -bin)/1000;

bar_mass = zeros(length(mu),n_bins); 

for i=2:length(d),
  
    if ( d(i) > d_min )
                    
        i_bin = find(d(i)>d_bins,1,'first')-1;
        
        bar_mass(:,i_bin) = bar_mass(:,i_bin) + x(:,i) * ( d(i) - d(i-1) );
        
    end
        
end

mass_fractions = sum(bar_mass,2)/sum(sum(bar_mass));

%%
% Plot of the total grain size distribution in phi-bins

subplot(5,1,5);

bin_half = 0.5d0 * ( bin(1:n_bins) + bin(2:n_bins+1) );

bar(bin_half,100*bar_mass'/sum(sum(bar_mass)),'stacked');
xlim([-log2(1000.0*d_max) -log2(1000.d0*d_min)]);
xlabel('Diameter (\phi)');
ylabel({'Total grain size';'distribution';'(mass %)'});


%% Evaluate analitically the moments

n_mom = 30;

mom = zeros(n_mom,length(mu));

mom_0(1:length(mu)) = C0 .* 6.d0 / pi * 10^(-3*(-3)) .* exp( (-3) ...
       * (-mu*log(2)) + 0.5 * ( -3 )^2 * ( sigma*log(2) ).^2 );

   
for k=1:n_mom,
          
   mom(k,1:length(mu)) = C0 .* 6.d0 / pi * 10^(-3*(k-3)) .* exp( (k-3) ...
       * (-mu*log(2)) + 0.5 * ( k-3 )^2 * ( sigma*log(2) ).^2 );
   
end

disp('Analytical moments');

disp(mom_0)
disp(mom(1,1:length(mu)))
disp(mom(2,1:length(mu)))
disp(mom(3,1:length(mu)))
disp(mom(4,1:length(mu)))

%% Evaluate numerically the moments

for i=1:length(mu),
    
    mom_check0(i) = sum(diff(d).* ( 0.5d0 * ...
        ( f(i,1:length(d)-1) ...
        + f(i,2:length(d)) ) ) );
 
    mom_phi0(i) = sum(diff(phi).* ( 0.5d0 * ...
        ( x_phi(i,1:length(d)-1) ...
        + x_phi(i,2:length(d)) ) ) );
    
    
    for k=1:n_mom,
        
        mom_check(k,i) = sum(diff(d).* ( 0.5d0 * ...
            ( f(i,1:length(d)-1) .* d(1:length(d)-1).^k ...
            + f(i,2:length(d)) .* d(2:length(d)).^k ) ) );
 
        mom_phi(k,i) = sum(diff(phi).* ( 0.5d0 * ...
            ( x_phi(i,1:length(d)-1) .* phi(1:length(d)-1).^k ...
            + x_phi(i,2:length(d)) .* phi(2:length(d)).^k ) ) );
        
    end
    
end

disp('Numerical moments');

disp(mom_check0)
disp(mom_check(1,1:length(mu)))
disp(mom_check(2,1:length(mu)))
disp(mom_check(3,1:length(mu)))
disp(mom_check(4,1:length(mu)))

disp('phi Numerical moments');

disp(mom_phi0)
disp(mom_phi(1,1:length(mu)))
disp(mom_phi(2,1:length(mu)))
disp(mom_phi(3,1:length(mu)))
disp(mom_phi(4,1:length(mu)))

tot_solid_volume_fraction = pi / 6.D0 * sum( mom(3,:) );

fprintf('Number of particles per unit volume %i\n', mom_0(1:length(mu)));
fprintf('Gas volume fraction %i\n', 1.D0 - tot_solid_volume_fraction);
fprintf('Particles mass fractions %i\n', mass_fractions(1:length(mu)));
fprintf('Number Averaged diameter of particles %d\n', mom(1,1:length(mu))./mom_0(1:length(mu)));
fprintf('Sauter mean diameter of particles %d\n', mom(3,1:length(mu))./mom(2,1:length(mu)));
fprintf('Volume averaged diameter of particles %d\n', mom(4,1:length(mu))./mom(3,1:length(mu)));
fprintf('Average volume of particles %d\n',mom(3,1:length(mu))./mom_0(1:length(mu)));

end


function [ f ] = log_norm2_d( x , C0 , mu, sigma )

bar_sigma = sigma * log(2);
bar_mu = - mu * log(2);
bar_x = 1000*x;

f1 = 6.d0 * 10^12 ./ ( pi * bar_x.^3 );

f2 = lognpdf(bar_x,bar_mu,bar_sigma);

f = C0 * f1 .* f2;

end



function [ rho ] = rho_function( d , d1 , d2 , rho1 , rho2 )

rho = d;

for i = 1:length(d)

    if ( d(i) <= d1 )
        
        rho(i) = rho1;
        
    elseif ( d(i) <= d2 )
        
        rho(i) = rho1 + ( d(i) - d1 ) / ( d2 - d1 ) * ( rho2 - rho1 );
        
    else
        
        rho(i) = rho2;
        
    end
    
end

end

function [ vel ] = settling_velocity( d , d1 , d2 , rho1 , rho2 )

vel = d;
% Textor et al. 2006

for i = 1:length(d)

    rhop = rho_function( d(i) , d1 , d2 , rho1 , rho2 );

    if ( d(i) <= 1.d-4 )
        
        k1 = 1.19D5;
        
        vel(i) = k1 * rhop .* ( 0.5D0 * d(i) ).^2;
        
    elseif ( d(i) <= 1.d-3 )
        
        k2 = 8.D0;
        
        vel(i) = k2 * rhop .* ( 0.5D0 * d(i) );
        
    else
        
        k3 = 4.833D0;
        CD = 0.75D0;
        
        vel(i) = k3 * sqrt( rhop / CD ) .* sqrt( 0.5D0 * d(i) );
        
    end
    
end
end