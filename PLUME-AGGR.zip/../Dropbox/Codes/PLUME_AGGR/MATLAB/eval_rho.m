clear all;

diam = logspace(log10(.5524271728E-5),log10(.09050966799187808),100);

n = length(diam);

DIAM1 = 8.d-6;
DIAM2 = 2.d-3;
RHO1 = 2500;
RHO2 = 1000;

for i=1:n,
    
       if ( diam(i) < DIAM1 ) 
           
       rho(i) = RHO1;

       elseif ( diam(i) < DIAM2 ) 

           rho(i) = RHO1 + ( log10(diam(i)) - log10(DIAM1) ) / ...
               ( log10(DIAM2) - log10(DIAM1) ) * ( RHO2 - RHO1 );
    
       else
           
           rho(i) = RHO2;

       end
    
end