function [ mom ] = eval_mom( x , k )

mu = x(1);
sigma = x(2);

mom = 6.d0 / pi * 10.^(-3.*(k-3)) .* exp( (k-3) ...
    .* (-mu*log(2)) + 0.5 * ( k-3 ).^2 * ( sigma*log(2) ).^2 );


end

