function rhop = part_dens(diam)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here

rhop = 2000.d0;

% rhop = 1.d0;

end

