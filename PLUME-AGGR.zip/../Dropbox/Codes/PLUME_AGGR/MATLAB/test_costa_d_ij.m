clear all;

plot_figure = 1;


%%

x_solid = 0.95;
rho_gas = 1.29;
rho_solid = 2000;


% rho_gas = 1;
% rho_solid = 1;
% pi = 6.0;

x_gas = 1.d0 - x_solid;

rho_mix = 1.0 / ( x_solid / rho_solid + x_gas / rho_gas );


t_init = 0.0d0;
t_final = 1.0d-2;

mu = 1.0;
sigma = 1.6;

n_mom = 8;

MOM_init = zeros(1,2*n_mom);

mu_bar = -log( 2.D0 ) * mu;
sigma_bar = log( 2.D0 ) * sigma;


for i = 0:n_mom-1,
        
    MOM_init(i+1) = 6.d0 / pi * 10.D0^(-3*(i-3)) * ...
        exp( ( i-3.D0 ) * mu_bar + ( i - 3.D0 )^2 / 2.D0 * ...
        sigma_bar^2 );
        
end

alfa_gas = x_gas * rho_mix / rho_gas; 
alfa_solid = 1.d0 - alfa_gas;

C0 = 6.D0 / pi * alfa_solid / MOM_init(4);

C0 = alfa_solid / MOM_init(4);

for i = 1:n_mom,
        
    MOM_init(i) = C0 * MOM_init(i);
        
end
  
aggr_fract = 0.5;

MOM_init(n_mom+1:2*n_mom) = aggr_fract * MOM_init(1:n_mom);

MOM_init(1:n_mom) = ( 1.0 - aggr_fract ) * MOM_init(1:n_mom);

MOM_init(4)

[d_i,wi_i,~]=WH(MOM_init(1:n_mom),n_mom/2);
[d_j,wi_j,~]=WH(MOM_init(n_mom+1:2*n_mom),n_mom/2);

sum(d_i.^3.*wi_i)
sum(wi_i)

pause
%%

abstol = 1e-3;

for i=1:n_mom-1,
    
    abstol = [ abstol 1e-2];
    
end

% options = odeset('RelTol',1e-4,'AbsTol',abstol);
options = odeset('RelTol',1e-5);

[T,Y] = ode23(@aggreg_d_jk,[t_init t_final],MOM_init',options);




mu_i = Y(:,5)./Y(:,4);

max_mu_i = max(mu_i);
min_mu_i = min(mu_i);

sigmai_2 = - ( Y(:,3)./Y(:,4) ).^2 + Y(:,2)./Y(:,4);

sigma_i = sqrt(sigmai_2);

mu_j = Y(:,n_mom+5)./Y(:,n_mom+4);

max_mu_j = max(mu_j);
min_mu_j = min(mu_j);

max_mu = max([max_mu_i,max_mu_j]);
min_mu = min([min_mu_i,min_mu_j]);



sigmaj_2 = - ( Y(:,n_mom+3)./Y(:,n_mom+4) ).^2 ...
    + Y(:,n_mom+2)./Y(:,n_mom+4);

sigma_j = sqrt(sigmaj_2);

max_sigma_i = max(sigma_i);
max_sigma_j = max(sigma_j);

max_sigma = max([max_sigma_i,max_sigma_j]);

N = n_mom/2;


for i=1:size(Y,1),
    
    [xi_i(i,:),w_i(i,:)] = WH(Y(i,1:n_mom),N);
    [xi_j(i,:),w_j(i,:)] = WH(Y(i,n_mom+1:2*n_mom),N);
    
end

xi_i_min = min(min(xi_i));
xi_i_max = max(max(xi_i));

w_i_min = min(min(w_i));
w_i_max = max(max(w_i));

xi_j_min = min(min(xi_j));
xi_j_max = max(max(xi_j));

w_j_min = min(min(w_j));
w_j_max = max(max(w_j));

xi_min = 0.1*min(xi_i_min,xi_j_min);
xi_max = 10*max(xi_i_max,xi_j_max);

w_min = min(w_i_min,w_j_min);
w_max = max(w_i_max,w_j_max);

if (plot_figure)
    
    fig = figure;
    
    subplot(4,1,1);
    hold all;
    grid on;box on;
    xlim([min(T),max(T)]);
    xlabel('time (s)');ylabel('M^{(3)}');
        
    
    subplot(4,1,2);
    grid on;
    hold all;box on;
    xlim([min(T),max(T)]);
    ylim([min_mu,max_mu]);
    
    plot([T(2),T(1)],[mu_i(2,1),mu_i(1,1)],'b-');
    
    plot([T(2),T(1)],[mu_j(2,1),mu_j(1,1)],'r-');
    
    
    legend('mu_i','mu_j');
    xlabel('time (s)');ylabel('Avg. diam.');
    
    subplot(4,1,3);
    grid on;
    hold all;box on;
    xlim([min(T),max(T)]);
    ylim([0,max_sigma]);
    xlabel('time (s)');ylabel('Std. dev.');
    
    subplot(4,1,4);box on;grid on;
    xlabel('Abscissas');ylabel('Weights');
    
    pause
        
    for i=2:size(Y,1),
        
        % plot number of particles - M0
        subplot(4,1,1);
        plot([T(i-1),T(i)],[pi/6*Y(i-1,4),pi/6*Y(i,4)],'b');
        plot([T(i-1),T(i)],[pi/6*Y(i-1,n_mom+4),pi/6*Y(i,n_mom+4)],'r');
                
        % plot the  mean diameter
        subplot(4,1,2);

        plot([T(i-1),T(i)],[mu_i(i-1,1),mu_i(i,1)],'b-');
        
        plot([T(i-1),T(i)],[mu_j(i-1,1),mu_j(i,1)],'r-');
        
        % plot the variance of the diameter
        subplot(4,1,3);
        plot([T(i-1),T(i)],[sigma_i(i-1,1),sigma_i(i,1)],'b');
        plot([T(i-1),T(i)],[sigma_j(i-1,1),sigma_j(i,1)],'r');
        
        subplot(4,1,4);
        loglog(xi_i(i,:),w_i(i,:),'bo',xi_j(i,:),w_j(i,:),'ro');box on;grid on;
        xlim([xi_min,xi_max]);
        ylim([max(1.e-10,w_min),w_max]);
        xlabel('abscissas (m)');ylabel('weights');
        
        pause(0.1);
                
    end
    
end

