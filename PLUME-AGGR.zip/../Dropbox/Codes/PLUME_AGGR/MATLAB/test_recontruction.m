clear all;

scrsz = get(0,'ScreenSize');

[filename, pathname] = uigetfile( '*.bak','Pick a file');

savefig = 0;

read_bak(pathname,filename)

filename = strcat(pathname,filename);

filename = strrep(filename,'.bak','');

run(strcat(filename,'.m'));

[ mom_0,mom ] = lognormal_moments( mu,sigma,gas_volume_fraction,...
    solid_mass_fractions,d1,d2,rho1,rho2);

n_mom = 30;

mom(2:n_mom,:) = mom(1:n_mom-1,:);
mom(1,:) = mom_0(:);

figure;

tgsd_min = -12;
tgsd_max = 14;

x_min = 1.d-3 * 2^(-tgsd_max);
x_max = 1.d-3 * 2^(-tgsd_min);

for i=1:size(mom,2),
    
    [xi(:,i),w(:,i),mom_quad]=WH(mom(:,i),n_mom/2);
    
    n_nodes = length(xi);
    
        
    dx = diff(xi(:,i));
    
    dx_l(1) = xi(1,i) - x_min;
    dx_l(2:n_nodes) = 0.5 * dx(1:n_nodes-1);
    
    dx_r(1:n_nodes-1) = 0.5 * dx(1:n_nodes-1);
    dx_r(n_nodes) = max(x_max,2*xi(n_nodes,1)) - xi(n_nodes,1);
    
    dx = dx_l + dx_r;
    
    w_dens(:,i) = w(:,i) ./dx';
    
    log10xi(:,i) = log10(xi(:,i));
    log10w_dens(:,i) = log10(w_dens(:,i));
     
    
    fit_log = fit(log10xi(:,i),log10w_dens(:,i),'poly2');
    
    x_log_grid(:,i) = linspace(log10(x_min),log10(x_max),250);
    
    p1 = fit_log.p1;
    p2 = fit_log.p2;
    p3 = fit_log.p3;
    
    y_log_grid(:,i) = p1*x_log_grid(:,i).^2 + p2*x_log_grid(:,i) + p3;
    
    
    f_vol(:,i) = w_dens(:,i) .* ( pi/6 * xi(:,i).^3 );
    f_vol_grid(:,i) = 10.^y_log_grid(:,i) .* ( pi/6 * (10.^x_log_grid(:,i)).^3 );
    
    subplot(2,1,1);
    plot(log10xi(:,i),log10w_dens(:,i),'o-');box on;
    hold all;
    plot(x_log_grid(:,i),y_log_grid(:,i));

    
    xlim([log10(x_min) log10(x_max)]);
    
    subplot(2,1,2);
    semilogx(xi(:,i),f_vol(:,i),'o-');box on;
    hold all;
    semilogx(10.^x_log_grid(:,i),f_vol_grid(:,i));box on;

    xlim([x_min x_max]);
    
end


