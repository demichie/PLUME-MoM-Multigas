function [xi,w,mom_quad]=PD(m,N)
%
% compute quadrature approximation with the Product-Difference algorithm
%
% INPUT:
%   N = number of nodes of the quadrature approximation 
%   m = moments from 0 to 2N-1 [mom(1), ..., mom(2N)]
%
% OUTPUT:
%   xi = abscissas
%   w  = weights
%
% compute matrix P
%
P(1,1)= 1.0;
for i=2:2*N+1
    P(i,1)=0.0;
end
for i=1:2*N
    P(i,2)=(-1)^(i-1)*m(i);
end
for j=3:2*N+1
    for i=1:2*N+2-j
        P(i,j)=P(1,j-1)*P(i+1,j-2)-P(1,j-2)*P(i+1,j-1);
    end
end
%
% compute coefficients of continued fraction
%
zeta(1)=0.0;
for i=2:2*N
%    if P(1,i)*P(1,i-1)>0.0
       zeta(i)=P(1,i+1)/(P(1,i)*P(1,i-1));
%    else
       % display('m1 is equal to zero!')
%       zeta(i)=0.0;
%   end
end
%
% compute coefficients for Jacobi matrix
%
for i=1:N
    a(i)=zeta(2*i)+zeta(2*i-1);
end
for i=1:N-1
    b(i) = zeta(2*i+1)*zeta(2*i);    
end
%
% compute Jacobi matrix
%
for i=1:N
    jacobi(i,i)=a(i);
end
for i=1:N-1
    jacobi(i,i+1) = -(b(i))^0.5;
    jacobi(i+1,i) = -(b(i))^0.5;
end

% jacobi
%
% compute eigenvalues and eigenvectors
%
[evec,eval]=eig(jacobi);
%
% return weights
%
for i=1:N
    w(i)=evec(1,i)^2*m(1);
end
%
% return abscissas
%
for i=1:N
    xi(i)=eval(i,i);
end

for i=1:2*N,
    
    mom_quad(i) = sum( (xi.^(i-1)).*w );
    
end
