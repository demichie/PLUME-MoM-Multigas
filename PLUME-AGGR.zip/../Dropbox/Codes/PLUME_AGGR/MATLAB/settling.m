function [Us,rho_atm] = settling(diam,z)

rho_p = 2000;

rho0_atm = 1.2255;

rho1_atm = rho0_atm * ( 1.d0 - 0.0226*10.8 )^4.255;


if ( z < 10.8 ) 
    
    rho_atm = rho0_atm * ( 1.d0 - 0.0226*z )^4.255;
    
else  

    rho_atm = rho1_atm * exp( -0.157 * ( z - 10.8 ) );
    
end

T0 = 288;
visc0 = 1.7910d-5;


visc1_atm = visc0 * ( T0 + 120 ) / ( T0 - 6.5*10.8 + 120 ) * ...
    ( ( T0 - 6.5 * 10.8 ) / T0 )^(1.5);


if ( z < 10.8 )
    
    visc_atm = visc0 * ( T0 + 120 ) / ( T0 - 6.5*z + 120 ) * ...
        ( ( T0 - 6.5 * z ) / T0 )^(1.5);
    
else
    
    visc_atm = visc1_atm;
end


mass = rho_p * 4/3 * pi * ( 0.5*diam )^3;

g = 9.81;

A_cs = pi * ( 0.5*diam )^2;

F = 0.43;

k1 = F^(-0.828);
k2 = 2.D0 * sqrt( 1.07 - F );


c0 = -2 * diam * mass * g;
c1 = 24 * visc_atm * k1 * A_cs;
c2 = rho_atm * diam * k2 * A_cs;

sqrt_delta = sqrt( c1^2 - 4 * c0*c2 );

Us_1 = ( - c1 + sqrt_delta ) / ( 2 * c2 );
Us_2 = ( - c1 - sqrt_delta ) / ( 2 * c2 );


Cd_100 = 24/100 * k1 + k2; 
Us_100 = sqrt( 2 * mass * g / ( Cd_100*rho_atm * A_cs ) );

Cd_1000 = 1.D0;
Us_1000 = sqrt( 2 * mass * g / ( Cd_1000*rho_atm * A_cs ) );


Rey1 = rho_atm * diam * Us_1 / visc_atm;
Rey2 = rho_atm * diam * Us_2 / visc_atm;

if ( Rey1 > 0 ) && ( Rey1 <= 100 ) 
    
    Us = Us_1;
        
elseif ( Rey1 > 100 ) && ( Rey1<1000) 
    
    Us = Us_100 + ( Rey1 - 100 ) / ( 1000 - 100 ) * ( Us_1000 - Us_100);

elseif ( Rey1 >= 1000 )
    
    Us = Us_1000;
       
end


if ( Rey2 > 0 ) && ( Rey2 < 100 ) 
    
    Us = Us_2;
    
elseif ( Rey2 > 100 ) && ( Rey2<1000) 
    
    Us = Us_100 + ( Rey2 - 100 ) / ( 1000 - 100 ) * ( Us_1000 - Us_100);

elseif ( Rey2 >= 1000 )
    
    Us = Us_1000;
       
end

CD1 = 24 / Rey1 * k1 + k2;
CD2 = 24 / Rey2 * k1 + k2;
