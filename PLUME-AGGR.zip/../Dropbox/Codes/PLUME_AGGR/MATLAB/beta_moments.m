function [ mom ] = beta_moments( p,q,d_max,solid_volume_fraction )

mom(3) = d_max^3 * beta(p+3,q) / beta(p,q);

C0 = 6.D0 / pi * solid_volume_fraction / mom(3);

log_dmax = log(d_max);

log_d = linspace(-20,log_dmax,5000);

d = exp(log_d);

f = beta_function( d,d_max,C0,p,q );


f_max = max(f);

ind = find(f>1.d-4*f_max,1,'first');

d_min = d(ind);

f_vol = f .* ( pi/6 * d.^3 );

h = figure;
set(h,'Color','w');
subplot(2,1,1)
semilogx(d(ind:end),f(ind:end));
%loglog(d(ind:end),f(ind:end));
xlabel('diam (m)');
ylabel('number of part. per unit vol.');

xlim([d_min d_max]);


subplot(2,1,2)
semilogx(d(ind:end),f_vol(ind:end));
xlabel('diam (m)');
ylabel('Part. volume per unit vol.');
xlim([d_min d_max]);

n_mom = 10;

for k=1:n_mom,
    
   mom(k) = C0 * d_max^(k-1) * beta(p+(k-1),q) / beta(p,q);
   
end

fprintf('Number of particles per unit volume %i\n', mom(1));
fprintf('Average diameter of particles %d\n', mom(2)/mom(1));
fprintf('Average volume of particles %d\n',mom(4)/mom(1));

end

function [ f ] = beta_function( x,x_max,C0,p,q )
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here

f = C0 / beta(p,q) * ( x.^(p-1) .* ( x_max - x ).^(q-1) ) / x_max^(p+q-1);

end

