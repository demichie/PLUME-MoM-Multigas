function [xi,w,mom_quad]=WH(m,N)
%
% compute quadrature approximation with the Wheeler algorithm
%
% INPUT:
%   N = number of nodes of the quadrature approximation 
%   m = moments from 0 to 2N-1 [mom(1), ..., mom(2N)]
%
% OUTPUT:
%   xi = abscissas
%   w  = weights


%
% compute intermediate coefficients
%
for l=1:2*N-2
    sigma(1,l+1) = 0.0;    
end
%
for l=0:2*N-1
    sigma(2,l+1) = m(l+1);
end


%
% compute coefficients for Jacobi matrix 
%
a(1) = m(2)/m(1);
b(1) = 0.0;
%
for k=1:N-1
    for l=k:2*N-k-1
        sigma(k+2,l+1) = sigma(k+1,l+2)-a(k)*sigma(k+1,l+1)-b(k)*sigma(k,l+1);
        a(k+1) = -sigma(k+1,k+1)/sigma(k+1,k)+sigma(k+2,k+2)/sigma(k+2,k+1); 
        b(k+1) = sigma(k+2,k+1)/sigma(k+1,k);
    end
end

% N
% size(sigma)

%
% compute Jacobi matrix
%
for i=1:N
    jacobi(i,i) = a(i);
end
%
for i=1:N-1
    jacobi(i,i+1) = -(abs(b(i+1)))^0.5;
    jacobi(i+1,i) = -(abs(b(i+1)))^0.5;
end

% jacobi

%
% compute eigenvalues and eigenvectors
%
[evec,eval]=eig(jacobi);

%eval

%evec
%
% return weights
%
for i=1:N
    w(i)=evec(1,i)^2*m(1);
end
%
% return abscissas
%
for i=1:N
    xi(i)=eval(i,i);
end



for i=1:2*N,
    
    mom_quad(i) = sum( (xi.^(i-1)).*w );
    
end
