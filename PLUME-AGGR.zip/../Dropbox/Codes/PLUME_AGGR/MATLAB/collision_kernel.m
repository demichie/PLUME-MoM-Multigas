function beta = collision_kernel( diam_1 , diam_2 )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

k_b =1.3806488D-23; 

visc_atm = 1.98D-5;

temp_part = 1000.D0;

beta_B = 2.D0 / 3.D0 * k_b * temp_part / visc_atm * ( diam_1 + diam_2 ).^2 ...
    ./ ( diam_1.*diam_2 );

% Value from Table 1 (Costa 2010)
Gamma_s = 0.0045D0;

beta_S = 1.D0 / 6.D0 * Gamma_s * ( diam_1 + diam_2 ).^3;

Vs_1 = part_set_vel(diam_1);

Vs_2 = part_set_vel(diam_2);

beta_DS = pi / 4.D0 * ( diam_1 + diam_2 ).^2 .* abs( Vs_2 - Vs_1 );

beta = beta_B + beta_S + beta_DS;

end

