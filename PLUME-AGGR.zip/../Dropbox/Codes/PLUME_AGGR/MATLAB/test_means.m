clear all;

mu = 4.0;
sigma = 1.6;

mu_bar = -mu * log(2);
sigma_bar = sigma * log(2);

n_mom = 5;

mom = zeros(1,n_mom);

mom_0 = 6.d0 / pi * 10^(-3*(-3)) .* exp( (-3) ...
       * (-mu*log(2)) + 0.5 * ( -3 )^2 * ( sigma*log(2) ).^2 );

for k=1:n_mom,
          
   mom(k) = 6.d0 / pi * 10^(-3*(k-3)) .* exp( (k-3) ...
       * (-mu*log(2)) + 0.5 * ( k-3 )^2 * ( sigma*log(2) ).^2 )/mom_0;
   
end

mom_0 = 1.D0;

D_A_mt = mom(3) / mom(2)

D_A = 10^(-3) * exp( mu_bar - 0.5 * sigma_bar^2 )

D_A_phi = -log2( D_A * 10^3 )

D_A_phi = mu + 0.5 * sigma^2 * log(2)

sigma_A_mt = sqrt( ( mom(1) * mom(3) - mom(2)^2 ) / ( mom(3)^2 ) )

sigma_A_mm = sigma_A_mt * 10^3;

sigma_A_phi = -log2( sigma_A_mm )

sigma_A_phi = - ( D_A_phi ) - 0.5 * log2( exp(sigma_bar^2) - 1 ) - 6 * log2(10)

mu_mt = mom(1)

mu_mm = mu_mt * 10^3;

mu_phi = -log2( mu_mm )

sigma_mt = sqrt( mom(2) - mom(1)^2 )

sigma_mm = sigma_mt * 10^3;

sigma_phi = -log2( sigma_mm )


%%

k1 = log( 1.D3 * mom(1) / mom_0 ); 
k2 = log( 1.D3 * mom(3) / mom(2) );

- 0.25D0 * ( 5*k2 - k1 ) / log(2)

sqrt( 0.5d0 * (k2-k1) ) / log(2)


