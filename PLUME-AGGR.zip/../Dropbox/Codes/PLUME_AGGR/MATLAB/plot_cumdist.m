figure

%subplot(4,1,1);
subplot(2,4,1);
hold all;
box on;

[n,xout] = hist(data(:,4),200);
ncum = cumsum(n)/max(cumsum(n));
plot(xout(1:10:end),ncum(1:10:end),'xk','LineWidth',1);

[n,xout] = hist(data_2000(:,4),200);
ncum = cumsum(n)/max(cumsum(n));
plot(xout(1:10:end),ncum(1:10:end),'o','LineWidth',1);

plot(cumdist_fn1_33(:,1),cumdist_fn1_33(:,2));
plot(cumdist_fn1_66(:,1),cumdist_fn1_66(:,2));
plot(cumdist_fn1_99(:,1),cumdist_fn1_99(:,2));

xlabel('Top TGSD \mu (\phi)');
ylabel('Cumulative probability');

%%

%subplot(4,1,2);
subplot(2,4,2);
hold all;
box on;

[n,xout] = hist(data(:,5),200);
ncum = cumsum(n)/max(cumsum(n));
plot(xout(1:10:end),ncum(1:10:end),'xk','LineWidth',1);

[n,xout] = hist(data_2000(:,5),200);
ncum = cumsum(n)/max(cumsum(n));
plot(xout(1:10:end),ncum(1:10:end),'o','LineWidth',1);

plot(cumdist_fn2_33(:,1),cumdist_fn1_33(:,2));
plot(cumdist_fn2_66(:,1),cumdist_fn1_66(:,2));
plot(cumdist_fn2_99(:,1),cumdist_fn1_99(:,2));

xlabel('Top TGSD \sigma (\phi)');
ylabel('Cumulative probability');

%%

%subplot(4,1,3);
subplot(2,4,3);
hold all;
box on;

[n,xout] = hist(data(:,6),200);
ncum = cumsum(n)/max(cumsum(n));
plot(xout(1:10:end),ncum(1:10:end),'xk','LineWidth',1);

[n,xout] = hist(data_2000(:,6),200);
ncum = cumsum(n)/max(cumsum(n));
plot(xout(1:10:end),ncum(1:10:end),'o','LineWidth',1);

plot(cumdist_fn3_33(:,1),cumdist_fn1_33(:,2));
plot(cumdist_fn3_66(:,1),cumdist_fn1_66(:,2));
plot(cumdist_fn3_99(:,1),cumdist_fn1_99(:,2));

xlabel('Plume height (m)');
ylabel('Cumulative probability');
%%

%subplot(4,1,4);
subplot(2,4,4);
hold all;
box on;

[n,xout] = hist(data(:,7),200);
ncum = cumsum(n)/max(cumsum(n));
plot(100*xout(1:10:end),ncum(1:10:end),'xk','LineWidth',1);

[n,xout] = hist(data_2000(:,7),200);
ncum = cumsum(n)/max(cumsum(n));
plot(100*xout(1:10:end),ncum(1:10:end),'o','LineWidth',1);

plot(100*cumdist_fn4_33(:,1),cumdist_fn1_33(:,2));
plot(100*cumdist_fn4_66(:,1),cumdist_fn1_66(:,2));
plot(100*cumdist_fn4_99(:,1),cumdist_fn1_99(:,2));

xlabel('Solid Mass Flux Loss (%)');
ylabel('Cumulative probability');

%%

data2 = data_2000(:,2);
data3 = data_2000(:,3);
data4 = data_2000(:,4);
data5 = data_2000(:,5);
data6 = data_2000(:,6);
data7 = data_2000(:,7);

subplot(2,4,5);
createFit(data2, data3, data4)
xlabel('Bottom TGSD \mu (\phi)');
ylabel('Bottom TGSD \sigma (\phi)');

subplot(2,4,6);
createFit(data2, data3, data5)
xlabel('Bottom TGSD \mu (\phi)');
ylabel('Bottom TGSD \sigma (\phi)');

subplot(2,4,7);
createFit(data2, data3, data6)
xlabel('Bottom TGSD \mu (\phi)');
ylabel('Bottom TGSD \sigma (\phi)');

subplot(2,4,8);
createFit(data2, data3, 100*data7)
xlabel('Bottom TGSD \mu (\phi)');
ylabel('Bottom TGSD \sigma (\phi)');
