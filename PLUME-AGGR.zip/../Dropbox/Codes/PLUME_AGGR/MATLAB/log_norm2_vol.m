function [ f ] = log_norm2_vol( x , mu, sigma )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

f = 1.d0 ./ ( sigma * sqrt( 2.D0 * pi ) * x * log(2) ) .* exp( - ( - log2( 1000 * x) ...
    - mu ).^2 / ( 2 * sigma^2 ) );

end

