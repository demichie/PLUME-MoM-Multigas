data1 = data(:,1);
data2 = data(:,2);
data3 = data(:,3);
data4 = data(:,4);
data5 = data(:,5);
data6 = data(:,6);
data7 = data(:,7);

figure;

%% mu top
subplot(4,2,1);

cdfplot(data4)
hold all
cdfplot(data2)

subplot(4,2,2);

createFit(data2,data3,data4)

%% sigma top
subplot(4,2,3);

cdfplot(data5)
hold all
cdfplot(data3)

subplot(4,2,4);

createFit(data2,data3,data5)

%% z top
subplot(4,2,5);

cdfplot(data6)

subplot(4,2,6);

createFit(data2,data3,data6)

%% solid mass flux ratio top/bottom
subplot(4,2,7);

cdfplot(data7)

subplot(4,2,8);

createFit(data2,data3,data7)

%%
figure

%% mu top
subplot(1,3,1);

createFit(data2,data3,data4)

subplot(1,3,2);

createFit(data2,data3,data5)

subplot(1,3,3);

createFit(data2,data3,data7)
